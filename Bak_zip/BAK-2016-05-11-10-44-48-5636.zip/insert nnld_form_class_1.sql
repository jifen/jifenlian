-- 表的数据: nnld_form_class --
INSERT INTO `nnld_form_class` VALUES ('1','新闻公告','0');-- <fen> --
