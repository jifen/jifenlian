-- 表的数据: nnld_fenhong --
INSERT INTO `nnld_fenhong` VALUES ('1','0.00','0');-- <fen> --
