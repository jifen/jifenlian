-- 表的数据: nnld_cptype --
INSERT INTO `nnld_cptype` VALUES ('2','枕头','0','0','0','0');-- <fen> --
