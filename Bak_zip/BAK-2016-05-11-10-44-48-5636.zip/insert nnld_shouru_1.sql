-- 表的数据: nnld_shouru --
INSERT INTO `nnld_shouru` VALUES ('4','10799','ldrj01','1000.00','1462934225','新会员加入','0');-- <fen> --
INSERT INTO `nnld_shouru` VALUES ('5','10800','ldrj02','1000.00','1462934261','新会员加入','0');-- <fen> --
INSERT INTO `nnld_shouru` VALUES ('6','10801','ldrj03','1000.00','1462934292','新会员加入','0');-- <fen> --
