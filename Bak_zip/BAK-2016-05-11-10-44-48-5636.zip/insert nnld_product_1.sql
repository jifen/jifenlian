-- 表的数据: nnld_product --
INSERT INTO `nnld_product` VALUES ('25','','华为mate8','0',NULL,NULL,'10000.00',NULL,NULL,'1461552093','\r\n \"\"\r\n\r\n','__PUBLIC__/Uploads/image/2016042510410715.jpg','0','0');-- <fen> --
INSERT INTO `nnld_product` VALUES ('27','','iphone6s','0',NULL,NULL,'20000.00',NULL,NULL,'1461552305','<p>&nbsp;<img src=\"/T049/Public/Uploads/iphone(2).jpg\" width=\"1000\" height=\"750\" alt=\"\" /></p>','__PUBLIC__/Uploads/image/2016042510444010.jpg','0','0');-- <fen> --
