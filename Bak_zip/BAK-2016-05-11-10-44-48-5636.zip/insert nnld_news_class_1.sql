-- 表的数据: nnld_news_class --
INSERT INTO `nnld_news_class` VALUES ('5','成衣','1295838556','0');-- <fen> --
INSERT INTO `nnld_news_class` VALUES ('6','汽车','1295838667','0');-- <fen> --
INSERT INTO `nnld_news_class` VALUES ('7','食品','1295838691','1');-- <fen> --
INSERT INTO `nnld_news_class` VALUES ('8','包包','1295840380','0');-- <fen> --
INSERT INTO `nnld_news_class` VALUES ('9','数码','1295853018','0');-- <fen> --
INSERT INTO `nnld_news_class` VALUES ('10','日常用品','1295853092','2');-- <fen> --
INSERT INTO `nnld_news_class` VALUES ('11','电子产品','1295921932','2');-- <fen> --
