-- 表的数据: nnld_img --
INSERT INTO `nnld_img` VALUES ('14','1','1404980111','http://www.baidu.com','/c009/Public/Uploads/image/2014091611205959.jpg','0');-- <fen> --
