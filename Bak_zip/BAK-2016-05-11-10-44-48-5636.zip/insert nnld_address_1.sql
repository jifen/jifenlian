-- 表的数据: nnld_address --
INSERT INTO `nnld_address` VALUES ('1','1','富贵','北京市','13899999999','1');-- <fen> --
